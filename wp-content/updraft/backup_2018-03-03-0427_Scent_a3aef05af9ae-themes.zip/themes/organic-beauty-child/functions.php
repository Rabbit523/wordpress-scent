<?php
/**
 * Child-Theme functions and definitions
 */

function henry_megamenu_javascript_localisation( $args ) {
    $args['timeout'] = 0;
    $args['interval'] = 0;
    return $args;
}
add_filter( 'megamenu_javascript_localisation', 'henry_megamenu_javascript_localisation', 10 );
