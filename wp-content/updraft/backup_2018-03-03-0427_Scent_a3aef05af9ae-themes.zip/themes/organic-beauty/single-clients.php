<?php
/*
 * Clients item
 */
get_template_part('single');
?>