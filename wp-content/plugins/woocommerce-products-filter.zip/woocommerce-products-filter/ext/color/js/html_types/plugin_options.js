jQuery(function($){
    $('.woof-color-picker').wpColorPicker();
});
