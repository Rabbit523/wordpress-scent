<div class="wrap">

	<h2>Help make WP All Export better.</h2>

	<table class="layout">
		<tbody>
			<tr>
				<td class="left">
					<p style="font-size: 1.3em !important;">
						<b>E-mail</b> - <a href="mailto:support@wpallimport.com?Subject=WP%20All%20Export%20feedback">support@wpallimport.com</a><br>
						<b>Support Form </b> - <a target="_blank" href="http://www.wpallimport.com/support/?utm_source=wordpress.org&utm_medium=feedback-page&utm_campaign=free+wp+all+export+plugin">http://www.wpallimport.com/support</a>
					</p>

					<p style="font-size: 1.3em !important;">Thanks for using WP All Export.</p>

					<p style="font-size: 1.3em !important;">Every day we work to improve WP All Export and we can't do that without hearing from you.</br>We'd love for you to get in touch and tell us about your experiences with WP All Export.</p>

					<p style="font-size: 1.3em !important;"><b>Which tasks do you use WP All Export for?</b></p>

					<p style="font-size: 1.3em !important;"><b>What do you wish WP All Export was able to do?</b></p>

					<p style="font-size: 1.3em !important;"><b>What is the most frustrating part of using WP All Export?</b></p>

				</td>
				<td class="right">&nbsp;</td>
			</tr>
		</tbody>
	</table>
</div>